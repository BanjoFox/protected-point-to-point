#############################################################################
# Disclaimer: Please make sure that you have ample rooting, hacking and
# flashing experience before you try this hack.  Velocite Systems will not be
# responsible if you end up damaging your device. This will also void
# your warranty.
#############################################################################

Original URL:
  http://www.addictivetips.com/mobile/root-motorola-photon-4g-with-a-single-click-guide-no-dock-required/

1. The first step is to download Photon Single Click root package from:

    http://forum.xda-developers.com/showthread.php?p=16632976#post16632976

  Extract the files and save them on your desktop. It is necessary that
  you extract all the files packed in zip package to one folder.

2. Once done, connect your phone to the computer and enable USB debugging.
  You can enable USB Debugging by going to
    Settings > Applications > Development
  and checkmark USB Debugging option.

3. Now connect your phone to the computer but do not mount SD Card or SD Ext.

4. Open the folder where you saved the rooting files and double click on
  PrevailToExistance.Bat file.

5. Now follow onscreen instructions closely to root your phone.

6. You now have root on your device.

