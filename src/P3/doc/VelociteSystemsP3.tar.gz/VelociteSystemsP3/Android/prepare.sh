mkfifo s2ufifo1
mkfifo u2sfifo1

