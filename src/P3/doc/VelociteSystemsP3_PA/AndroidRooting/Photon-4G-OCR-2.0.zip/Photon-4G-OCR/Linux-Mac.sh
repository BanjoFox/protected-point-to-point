#!/bin/bash
# Unix OS Sniffer and $adb setup by Firon
platform=`uname`;
adb="adb";
if [ $(uname -p) == 'powerpc' ]; then
	echo "Sorry, this won't work on PowerPC machines."
exit 1
fi
cd "$(dirname "$0")"
if [ -z $(which adb) ]; then
	adb="./adb";
	if [ "$platform" == 'Darwin' ]; then
		mv adb.osx $adb > /dev/null 2>&1
	fi
fi
chmod +x $adb
# End section, thanks Firon!
echo based off droid 3 root script found here http://rootzwiki.com/showthread.php?t=3714&p=75934&viewfull=1#post75934
clear
echo
echo          "Root for the Moto Photon 4G"
echo
echo                   "By Bliss"
echo           
echo               "One Click Done by"
echo                 "Shabbypenguin"
echo
read -n1 -s -p "Press any key to continue..."

echo -e "Starting adb server"

if [ -z $(which sudo 2>/dev/null) ]; then
	$adb kill-server
else
	sudo $adb kill-server
fi
if [ -z $(which sudo 2>/dev/null) ]; then
	$adb start-server
else
	sudo $adb start-server
fi
echo      "You need to enable usb debugging first"
echo    "Go to settings > applications > development"
sleep 2



$adb wait-for-device
$adb wait-for-device
echo "* Running exploit [part 1 of 3]..."
$adb shell rm /data/local/12m.bak
$adb shell mv /data/local/12m /data/local/12m.bak
$adb shell ln -s /data /data/local/12m
$adb reboot
echo "RE-boot-en"

$adb kill-server
$adb wait-for-device
$adb wait-for-device
echo "* Running exploit [part 2 of 3]..."
$adb shell rm /data/local/12m
$adb shell mv /data/local/12m.bak /data/local/12m
$adb shell "if [ -e /data/local.prop.bak ]; then rm /data/local.prop.bak; fi"
$adb shell mv /data/local.prop /data/local.prop.bak
$adb shell 'echo "ro.sys.atvc_allow_netmon_usb=0" > /data/local.prop'
$adb shell 'echo "ro.sys.atvc_allow_netmon_ih=0" > /data/local.prop'
$adb shell 'echo "ro.sys.atvc_allow_res_core=0" >> /data/local.prop'
$adb shell 'echo "ro.sys.atvc_allow_res_panic=0" >> /data/local.prop'
$adb shell 'echo "ro.sys.atvc_allow_all_adb=1" >> /data/local.prop'
$adb shell 'echo "ro.sys.atvc_allow_all_core=0" >> /data/local.prop'
$adb shell 'echo "ro.sys.atvc_allow_efem=0" >> /data/local.prop'
$adb shell 'echo "ro.sys.atvc_allow_bp_log=0" >> /data/local.prop'
$adb shell 'echo "ro.sys.atvc_allow_ap_mot_log=0" >> /data/local.prop'
$adb shell 'echo "ro.sys.atvc_allow_gki_log=0" >> /data/local.prop'
$adb reboot

$adb kill-server
$adb wait-for-device
$adb wait-for-device

echo "deleting all yo shit"

echo "Wait for phone to reconnect..."
$adb remount
$adb push rootsetup /data/local/tmp/rootsetup
$adb shell chmod 755 /data/local/tmp/rootsetup
$adb shell /data/local/tmp/rootsetup
$adb shell rm /data/local/tmp/rootsetup
$adb shell sync

echo "Copying files onto phone..."
$adb push su /system/xbin/su
$adb push Superuser.apk /system/app/Superuser.apk
$adb push busybox /system/xbin/busybox
$adb push remount /system/xbin/remount

echo "Setting permissions..."
$adb shell chmod 755 /system/xbin/busybox
$adb shell chmod 755 /system/xbin/remount
$adb shell chown root.shell /system/xbin/su
$adb shell chmod 4755 /system/xbin/su
$adb shell ln -s /system/xbin/su /system/bin/su


echo "Installing busybox..."
$adb shell /system/xbin/busybox --install -s /system/xbin

echo "Cleaning up files..."
sleep 5;
$adb shell rm /data/local/tmp/*
$adb reboot

if [ -z $(which sudo 2>/dev/null) ]; then
	$adb kill-server
else
	sudo $adb kill-server
fi
echo "All done!"
echo
read -n1 -s -p "Press any key to exit the script."
echo
