Read Me First!!!

First turn on android debugging
	Press menu
	then settings
	next Applications
	Finally Development
	ensure the box for USB debugging is checked
	press home

Windows

double click on the root.bat file

follow the on-screen prompts from the window that will pop up.



Mac/linux 

open  terminal
cd to the direcory that has the one click
sudo chmod 755 Linux-Mac.sh
./Linux-Mac.sh

